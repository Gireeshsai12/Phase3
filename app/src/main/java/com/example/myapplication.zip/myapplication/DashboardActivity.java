package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    TextView tvWelcome;
    Button btnBrowse, btnTranscript;

    String userId;
    String role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tvWelcome = findViewById(R.id.tvWelcome);
        btnBrowse = findViewById(R.id.btnBrowse);
        btnTranscript = findViewById(R.id.btnTranscript);

        userId = getIntent().getStringExtra("user_id");
        role = getIntent().getStringExtra("role");

        tvWelcome.setText("Welcome " + userId + " (" + role + ")");

        btnBrowse.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, BrowseCoursesActivity.class);
            intent.putExtra("user_id", userId);
            intent.putExtra("role", role);
            startActivity(intent);
        });

        btnTranscript.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, TranscriptActivity.class);
            intent.putExtra("user_id", userId);
            intent.putExtra("role", role);
            startActivity(intent);
        });
    }
}